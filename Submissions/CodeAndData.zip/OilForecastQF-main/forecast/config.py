"""Configuration shared by training and the daily run (values taken from the team's lasso.ipynb)."""
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import List, Optional

ROOT = Path(__file__).resolve().parent.parent
RAW_DIR = ROOT / "Data" / "raw"
MODELS_DIR = ROOT / "models"
OUTPUT_DIR = ROOT / "Outputs"


@dataclass
class Config:
    # ---- data ----
    target: str = "brent_fut"
    # quoted as levels / rates / indices: first differences plus the level
    level_series: List[str] = field(default_factory=lambda: [
        "vix", "ovx", "ust10y", "curve_10y2y", "t10y3m", "breakeven10y", "epu"])
    exclude: List[str] = field(default_factory=lambda: ["wti_spot", "brent_spot"])   # published with delays
    ffill_limit: int = 3
    slow_ffill_limit: int = 7
    feature_lag: int = 0
    fred_lag: int = 1                 # FRED daily series known the next day
    season_years: int = 5
    weekly_stale_days: int = 21
    weekly_release_lag: int = 6       # weekly series enter 6 days after the period date

    # series the LASSO-family and MS-AR plugins forecast (each gets its own panel in the e-mail)
    targets: List[str] = field(default_factory=lambda: ["brent_fut", "wti_fut"])
    # a target's prices before this date are not used: WTI settled at -37.63 on 2020-04-20, which would put a -60% "return"
    # into the estimation windows. (Other series, e.g. WTI as a predictor of Brent, are untouched.)
    series_start: dict = field(default_factory=lambda: {"wti_fut": "2020-06-01"})

    # ---- forecasting ----
    horizons: List[int] = field(default_factory=lambda: [1, 5, 10, 20, 40, 60])
    window: int = 1260                # rolling estimation window (trading days)
    cv_folds: int = 5
    n_alphas: int = 40
    lasso_eps: float = 1e-2
    fit_intercept: bool = False
    pca_kmax: int = 8
    pca_k: Optional[int] = None
    tpca_t: float = 1.65
    rs_patterns: tuple = ("__lvl", "__anom", "20")
    seed: int = 0

    # ---- regimes ----
    hmm_k: int = 2
    hmm_inputs: List[str] = field(default_factory=lambda: ["ret"])
    hmm_min_obs: int = 500
    hmm_refit: int = 63
    hmm_window: Optional[int] = None

    # the notebooks read yahoo_daily.csv only, so USD/CAD, USD/NOK and EEM (in yahoo_extra_daily.csv) were never among their
    # predictors; set True to add them to the LASSO and XGBoost inputs
    tab_extra_markets: bool = False

    # ---- regime-dependent LASSO plugin (teammate's lasson.ipynb) ----
    lr_cv_folds: int = 5                  # time-ordered cross-validation folds inside the window (gap of h days)
    lr_n_alphas: int = 30
    lr_eps: float = 1e-2                  # smallest penalty = 1% of the largest
    lr_shrink: float = 0.5                # final forecast = 0.5 x LASSO (equal-weight combination with no change)
    lr_min_duration: int = 120            # each regime lasts at least 120 trading days in expectation, and in the label
    lr_enter_p: float = 0.7               # label turns turbulent if P(turbulent) > 0.7 for lr_confirm days ...
    lr_exit_p: float = 0.3                # ... and back to calm if < 0.3 for lr_confirm days
    lr_confirm: int = 10
    lr_refit_every: int = 21              # back-fill only: re-estimate every 21 trading days (about monthly), as in the notebook

    # ---- XGBoost plugin (teammate's xgbn.ipynb) ----
    xgb_n_estimators: int = 500
    xgb_learning_rate: float = 0.03
    xgb_max_depth: int = 3
    xgb_min_child_weight: float = 50
    xgb_subsample: float = 0.7
    xgb_colsample: float = 0.7
    xgb_reg_lambda: float = 10.0
    xgb_early_stopping: int = 50
    xgb_inner_val: int = 252              # last 252 rows of the window (after an h-day gap) decide when to stop adding trees
    xgb_seed: int = 7
    xgb_shrink: float = 0.5
    xgb_pca_min_eig: float = 1.0          # PCA variable selection: keep components with eigenvalue > 1 (Kaiser)
    xgb_refit_every: int = 21
    xgb_use_regime: bool = True           # add P(turbulent) and the regime label as inputs (kept after the PCA selection)
    xgb_min_duration: int = 65            # regimes last at least one quarter (65 trading days), in expectation and in the label
    xgb_enter_p: float = 0.7
    xgb_exit_p: float = 0.3
    xgb_confirm: int = 10

    # ---- ARMA-GARCH plugin (teammate's gp_arma_garch.ipynb: MA(2) mean, GARCH(1,1)-t on its residuals) ----
    arma_order: tuple = (0, 2)                        # (p, q); zero-mean ARMA fitted on daily log returns
    garch_pq: tuple = (1, 1)
    garch_dist: str = "t"
    arma_garch_targets: List[str] = field(default_factory=lambda: ["brent_fut", "wti_fut"])

    # ---- MS-AR plugin (teammate's msar_common.ipynb: MS-AR and MS-ARX on a common Brent / WTI calendar) ----
    msar_window: int = 1260               # estimation window (returns) for both models
    msar_shrink: float = 0.5              # point forecast = 0.5 x the model's exact mean (equal-weight mix with no change)
    msar_refit_every: int = 21            # back-fill only: re-estimate every 21 trading days, as in the notebook
    msar_seed: int = 5210
    msar_n_sim: int = 2000                # simulated paths per origin for the band
    msar_fill_limit: int = 3              # causal forward-fill limit for the dollar index

    # ---- frozen-model evaluation (scripts/frozen_eval.py) ----
    frozen_cutoff: str = "2024-12-31"        # models are estimated / selected on data up to and including this date
    frozen_fan_origin: str = "2026-07-01"    # origin of the one-off "forecast fan vs actual" picture
    frozen_horizons: tuple = (1, 2, 3, 5, 10, 20, 40, 60)   # evaluated horizons (tables); charts use the short ones
    frozen_chart_horizon: int = 3            # rolling h-day-ahead chart
    frozen_trade_horizon: int = 3            # horizon of the trading rule shown in the e-mail table and equity chart
    frozen_zoom_days: int = 90               # price panel of the rolling chart shows the last N origins
    signal_horizon: int = 1                  # horizon of the BUY / SELL / HOLD summary at the top of the e-mail
    cost_bps: float = 5.0                    # transaction cost per unit of turnover (basis points)
    trade_band: float = 0.1                  # trade only if |forecast| > band * (1-sd of the h-day return)

    # ---- combination ----
    combo_pool: List[str] = field(default_factory=lambda: ["RW", "LASSO", "LASSO_1se", "PCA_reg", "TPCA", "LASSO_RS"])

    def to_dict(self):
        return asdict(self)
